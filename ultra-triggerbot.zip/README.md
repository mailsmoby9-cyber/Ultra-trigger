# Ultra Instinct TriggerBot (Fabric, Minecraft 1.21.11)

Клиентский мод: автоматически бьёт цель под прицелом с учётом перезарядки, критов и комбо.
Клавиша **R** включает/выключает (переназначается в Настройки -> Управление).

Настройки: `config/ultra_triggerbot.properties` (создаётся при первом запуске).

Сборка: GitHub Actions (вкладка Actions -> Build mod -> Artifacts) или локально `gradle build` (Java 21).
Для работы нужны Fabric Loader 0.18.1+ и Fabric API для 1.21.11.
