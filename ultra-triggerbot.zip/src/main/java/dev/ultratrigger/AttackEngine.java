package dev.ultratrigger;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Vec3d;

/**
 * Основная логика: раз в клиентский тик проверяет цель под прицелом и решает, бить ли.
 * Перезарядка атаки в Minecraft считается в тиках, поэтому проверка раз в тик
 * даёт удар в первый же возможный момент.
 */
final class AttackEngine {
    private final TriggerConfig cfg;
    private final MotionTracker motion = new MotionTracker();
    private int critWaitTicks;

    AttackEngine(TriggerConfig cfg) {
        this.cfg = cfg;
    }

    void reset() {
        motion.reset();
        critWaitTicks = 0;
    }

    void tick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.world == null || client.interactionManager == null) {
            reset();
            return;
        }

        motion.observeSelf(player);
        if (player.isOnGround()) critWaitTicks = 0;

        if (!canAct(client, player)) {
            motion.clearTarget();
            return;
        }

        // Цель берём из ванильного прицела: он уже учитывает дальность и блоки на пути.
        if (!(client.crosshairTarget instanceof EntityHitResult hit)) {
            motion.clearTarget();
            return;
        }
        Entity target = hit.getEntity();
        if (!TargetFilter.isValid(player, target, cfg)) {
            motion.clearTarget();
            return;
        }

        Vec3d eye = player.getEyePos();
        Vec3d hitPos = hit.getPos();
        if (cfg.requireLineOfSight && !TargetFilter.hasClearLine(client.world, player, eye, hitPos)) {
            motion.clearTarget();
            return;
        }

        motion.observeTarget(target);

        if (cfg.pauseWhileUsingItem && player.isUsingItem()) return;
        if (player.getAttackCooldownProgress(0.0f) < cfg.minCooldown) return;

        LivingEntity living = (LivingEntity) target;
        if (cfg.skipInvulnerable && living.hurtTime > cfg.maxHurtTime) return;

        boolean escaping = cfg.smartCombo
                && motion.isEscaping(eye, hitPos, player.getEntityInteractionRange(), cfg.retreatMargin);

        if (CritLogic.shouldWait(player, cfg, critWaitTicks, escaping)) {
            critWaitTicks++;
            return;
        }

        client.interactionManager.attackEntity(player, target);
        player.swingHand(Hand.MAIN_HAND);
        critWaitTicks = 0;
    }

    /** Общие условия, при которых бот не должен вмешиваться в игру. */
    private static boolean canAct(MinecraftClient client, ClientPlayerEntity player) {
        return client.currentScreen == null
                && client.isWindowFocused()
                && player.isAlive()
                && !player.isSpectator()
                // игрок бьёт сам - не дублируем клик
                && !client.options.attackKey.isPressed();
    }
}
