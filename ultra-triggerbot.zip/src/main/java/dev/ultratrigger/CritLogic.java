package dev.ultratrigger;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffects;

/** Условия критического удара по ванильным правилам Minecraft. */
final class CritLogic {
    private CritLogic() {}

    /** Состояние игрока, при котором крит в принципе невозможен (ждать бесполезно). */
    static boolean critBlockedByState(ClientPlayerEntity p) {
        return p.isSprinting()
                || p.isClimbing()
                || p.isTouchingWater()
                || p.hasVehicle()
                || p.hasStatusEffect(StatusEffects.BLINDNESS)
                || p.getAbilities().flying;
    }

    /** Удар прямо сейчас будет критическим. */
    static boolean canCritNow(ClientPlayerEntity p) {
        return p.fallDistance > 0.0
                && !p.isOnGround()
                && !critBlockedByState(p);
    }

    /**
     * Стоит ли подождать ещё тик ради крита.
     * Ждём только в фазе подъёма прыжка, не дольше лимита и не когда цель уходит.
     */
    static boolean shouldWait(ClientPlayerEntity p, TriggerConfig cfg, int waited, boolean targetEscaping) {
        if (!cfg.smartCrits || targetEscaping) return false;
        if (p.isOnGround()) return false;
        if (critBlockedByState(p)) return false;
        if (canCritNow(p)) return false;
        return waited < cfg.maxCritWaitTicks;
    }
}
