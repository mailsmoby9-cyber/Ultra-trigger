package dev.ultratrigger;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Properties;

/** Настройки мода. Файл: config/ultra_triggerbot.properties (создаётся при первом запуске). */
public final class TriggerConfig {

    public enum TargetMode { ALL, PLAYERS, MOBS, HOSTILE }

    public TargetMode targetMode = TargetMode.ALL;
    public float minCooldown = 1.0f;
    public boolean requireLineOfSight = true;
    public boolean pauseWhileUsingItem = true;
    public boolean ignoreOwnPets = true;
    public boolean ignoreCreativePlayers = true;
    public boolean skipInvulnerable = true;
    public int maxHurtTime = 2;
    public boolean smartCrits = true;
    public int maxCritWaitTicks = 8;
    public boolean smartCombo = true;
    public double retreatMargin = 0.3;
    public boolean persistentIndicator = true;

    private TriggerConfig() {}

    public static TriggerConfig loadOrCreate() {
        TriggerConfig cfg = new TriggerConfig();
        Path path = FabricLoader.getInstance().getConfigDir().resolve(UltraTriggerBot.MOD_ID + ".properties");

        if (Files.exists(path)) {
            try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
                Properties props = new Properties();
                props.load(reader);
                cfg.apply(props);
            } catch (IOException | RuntimeException e) {
                UltraTriggerBot.LOGGER.warn("Не удалось прочитать конфиг, используются значения по умолчанию", e);
            }
        }
        cfg.clamp();

        try {
            Files.writeString(path, cfg.render(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            UltraTriggerBot.LOGGER.warn("Не удалось записать конфиг {}", path, e);
        }
        return cfg;
    }

    private void apply(Properties p) {
        targetMode = readEnum(p, "targetMode", targetMode);
        minCooldown = (float) readDouble(p, "minCooldown", minCooldown);
        requireLineOfSight = readBool(p, "requireLineOfSight", requireLineOfSight);
        pauseWhileUsingItem = readBool(p, "pauseWhileUsingItem", pauseWhileUsingItem);
        ignoreOwnPets = readBool(p, "ignoreOwnPets", ignoreOwnPets);
        ignoreCreativePlayers = readBool(p, "ignoreCreativePlayers", ignoreCreativePlayers);
        skipInvulnerable = readBool(p, "skipInvulnerable", skipInvulnerable);
        maxHurtTime = (int) readDouble(p, "maxHurtTime", maxHurtTime);
        smartCrits = readBool(p, "smartCrits", smartCrits);
        maxCritWaitTicks = (int) readDouble(p, "maxCritWaitTicks", maxCritWaitTicks);
        smartCombo = readBool(p, "smartCombo", smartCombo);
        retreatMargin = readDouble(p, "retreatMargin", retreatMargin);
        persistentIndicator = readBool(p, "persistentIndicator", persistentIndicator);
    }

    private void clamp() {
        minCooldown = Math.max(0.5f, Math.min(1.0f, minCooldown));
        maxHurtTime = Math.max(0, Math.min(10, maxHurtTime));
        maxCritWaitTicks = Math.max(0, Math.min(20, maxCritWaitTicks));
        retreatMargin = Math.max(0.0, Math.min(2.0, retreatMargin));
    }

    private String render() {
        StringBuilder sb = new StringBuilder();
        sb.append("# Ultra Instinct TriggerBot - настройки\n");
        sb.append("# Изменения применяются при следующем запуске игры.\n\n");

        sb.append("# Кого бить: ALL (все живые), PLAYERS (только игроки),\n");
        sb.append("# MOBS (все, кроме игроков), HOSTILE (только враждебные мобы)\n");
        sb.append("targetMode=").append(targetMode.name()).append("\n\n");

        sb.append("# Минимальная перезарядка атаки для удара: 0.5 .. 1.0 (1.0 = полный урон)\n");
        sb.append("minCooldown=").append(minCooldown).append("\n\n");

        sb.append("# Не бить, если между вами и целью есть блок\n");
        sb.append("requireLineOfSight=").append(requireLineOfSight).append("\n\n");

        sb.append("# Не бить, пока вы едите, пьёте, целитесь или блокируете щитом\n");
        sb.append("pauseWhileUsingItem=").append(pauseWhileUsingItem).append("\n\n");

        sb.append("# Не бить своих приручённых питомцев\n");
        sb.append("ignoreOwnPets=").append(ignoreOwnPets).append("\n\n");

        sb.append("# Не бить игроков в креативе (им нельзя нанести урон)\n");
        sb.append("ignoreCreativePlayers=").append(ignoreCreativePlayers).append("\n\n");

        sb.append("# Не бить цель в кадрах неуязвимости после удара.\n");
        sb.append("# maxHurtTime: 0 = строго после окончания, 10 = не фильтровать.\n");
        sb.append("# При высоком пинге можно поднять до 3-4.\n");
        sb.append("skipInvulnerable=").append(skipInvulnerable).append("\n");
        sb.append("maxHurtTime=").append(maxHurtTime).append("\n\n");

        sb.append("# Крит: в прыжке ждать фазу падения (не дольше maxCritWaitTicks тиков).\n");
        sb.append("# Если крит невозможен (спринт, вода, лестница, полёт) - ждать не будет.\n");
        sb.append("smartCrits=").append(smartCrits).append("\n");
        sb.append("maxCritWaitTicks=").append(maxCritWaitTicks).append("\n\n");

        sb.append("# Комбо: если цель вот-вот выйдет из зоны досягаемости (отбрасывание, отступление),\n");
        sb.append("# бить сразу, не дожидаясь крита. retreatMargin - запас по дистанции в блоках.\n");
        sb.append("smartCombo=").append(smartCombo).append("\n");
        sb.append("retreatMargin=").append(retreatMargin).append("\n\n");

        sb.append("# Постоянно показывать статус ON над хотбаром, пока бот включён\n");
        sb.append("persistentIndicator=").append(persistentIndicator).append("\n");
        return sb.toString();
    }

    private static boolean readBool(Properties p, String key, boolean def) {
        String v = p.getProperty(key);
        if (v == null) return def;
        v = v.trim().toLowerCase(Locale.ROOT);
        if (v.equals("true")) return true;
        if (v.equals("false")) return false;
        return def;
    }

    private static double readDouble(Properties p, String key, double def) {
        String v = p.getProperty(key);
        if (v == null) return def;
        try {
            return Double.parseDouble(v.trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private static <E extends Enum<E>> E readEnum(Properties p, String key, E def) {
        String v = p.getProperty(key);
        if (v == null) return def;
        try {
            return Enum.valueOf(def.getDeclaringClass(), v.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            return def;
        }
    }
}
