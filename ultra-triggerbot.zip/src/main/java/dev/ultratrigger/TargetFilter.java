package dev.ultratrigger;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

/** Решает, можно ли и нужно ли бить данное существо. */
final class TargetFilter {
    private TargetFilter() {}

    static boolean isValid(ClientPlayerEntity self, Entity target, TriggerConfig cfg) {
        if (!(target instanceof LivingEntity living)) return false;
        if (living == self || !living.isAlive() || !living.isAttackable()) return false;
        if (living instanceof ArmorStandEntity) return false;

        if (living instanceof PlayerEntity other) {
            if (other.isSpectator()) return false;
            if (cfg.ignoreCreativePlayers && other.isCreative()) return false;
        }
        if (cfg.ignoreOwnPets && living instanceof TameableEntity pet && pet.isOwner(self)) return false;

        return switch (cfg.targetMode) {
            case ALL -> true;
            case PLAYERS -> living instanceof PlayerEntity;
            case MOBS -> !(living instanceof PlayerEntity);
            case HOSTILE -> living instanceof Monster;
        };
    }

    /** Свободна ли линия от глаз до точки попадания (по контуру блоков, как у ванильного прицела). */
    static boolean hasClearLine(World world, ClientPlayerEntity self, Vec3d eye, Vec3d hitPos) {
        RaycastContext ctx = new RaycastContext(
                eye, hitPos,
                RaycastContext.ShapeType.OUTLINE,
                RaycastContext.FluidHandling.NONE,
                self);
        return world.raycast(ctx).getType() == HitResult.Type.MISS;
    }
}
