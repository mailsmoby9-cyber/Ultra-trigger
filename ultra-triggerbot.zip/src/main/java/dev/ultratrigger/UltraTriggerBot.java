package dev.ultratrigger;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class UltraTriggerBot implements ClientModInitializer {
    public static final String MOD_ID = "ultra_triggerbot";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static final int INDICATOR_REFRESH_TICKS = 40;

    private TriggerConfig config;
    private AttackEngine engine;
    private KeyBinding toggleKey;
    private boolean enabled;
    private int indicatorTimer;

    @Override
    public void onInitializeClient() {
        config = TriggerConfig.loadOrCreate();
        engine = new AttackEngine(config);

        // Клавиша R по умолчанию. Конфликты видно в Настройки -> Управление (подсвечиваются красным),
        // клавишу можно переназначить там же.
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key." + MOD_ID + ".toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_R,
                KeyBinding.Category.create(Identifier.of(MOD_ID, "main"))));

        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
        LOGGER.info("Ultra Instinct TriggerBot загружен");
    }

    private void onTick(MinecraftClient client) {
        // Переключение обрабатывается первым - срабатывает в тот же тик.
        while (toggleKey.wasPressed()) {
            enabled = !enabled;
            engine.reset();
            showStatus(client);
        }
        if (!enabled) return;

        try {
            engine.tick(client);
        } catch (RuntimeException e) {
            // Любая неожиданная ошибка (например, несовместимость маппингов) - выключаемся, а не роняем игру.
            enabled = false;
            engine.reset();
            LOGGER.error("TriggerBot выключен из-за ошибки", e);
            if (client.player != null) {
                client.player.sendMessage(
                        Text.translatable("text.ultra_triggerbot.error").formatted(Formatting.RED), true);
            }
            return;
        }

        if (config.persistentIndicator && ++indicatorTimer >= INDICATOR_REFRESH_TICKS) {
            showStatus(client);
        }
    }

    private void showStatus(MinecraftClient client) {
        indicatorTimer = 0;
        if (client.player == null) return;
        Text state = enabled
                ? Text.translatable("text.ultra_triggerbot.on").formatted(Formatting.GREEN)
                : Text.translatable("text.ultra_triggerbot.off").formatted(Formatting.RED);
        client.player.sendMessage(Text.translatable("text.ultra_triggerbot.status", state), true);
    }
}
