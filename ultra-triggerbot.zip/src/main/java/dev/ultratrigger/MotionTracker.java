package dev.ultratrigger;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;

/**
 * Следит за смещением игрока и цели от тика к тику.
 * Нужен для анализа отбрасывания и отступления: на клиенте скорость чужих
 * игроков ненадёжна, поэтому считаем её по реальным позициям.
 */
final class MotionTracker {
    private Vec3d selfPrev;
    private Vec3d selfDelta = Vec3d.ZERO;

    private int targetId = -1;
    private Vec3d targetPrev;
    private Vec3d targetDelta = Vec3d.ZERO;

    void observeSelf(Entity self) {
        Vec3d now = pos(self);
        selfDelta = selfPrev == null ? Vec3d.ZERO : now.subtract(selfPrev);
        selfPrev = now;
    }

    void observeTarget(Entity target) {
        Vec3d now = pos(target);
        boolean same = target.getId() == targetId && targetPrev != null;
        targetDelta = same ? now.subtract(targetPrev) : Vec3d.ZERO;
        targetId = target.getId();
        targetPrev = now;
    }

    void clearTarget() {
        targetId = -1;
        targetPrev = null;
        targetDelta = Vec3d.ZERO;
    }

    void reset() {
        clearTarget();
        selfPrev = null;
        selfDelta = Vec3d.ZERO;
    }

    /**
     * true, если на следующем тике точка попадания, скорее всего, выйдет за пределы
     * дальности атаки (цель отбросило или она отступает), а сейчас она ещё в зоне.
     */
    boolean isEscaping(Vec3d eye, Vec3d hitPos, double reach, double margin) {
        if (targetPrev == null) return false;
        Vec3d toHit = hitPos.subtract(eye);
        Vec3d relative = targetDelta.subtract(selfDelta);
        double now = toHit.length();
        double next = toHit.add(relative).length();
        return next > now && next > reach - margin;
    }

    private static Vec3d pos(Entity e) {
        return new Vec3d(e.getX(), e.getY(), e.getZ());
    }
}
